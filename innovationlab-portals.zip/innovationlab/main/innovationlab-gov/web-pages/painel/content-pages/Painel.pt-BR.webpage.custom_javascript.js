function requestBenefits(eligibleBenefitId) {
   location.href = "/servicos/solicitacao-de-beneficio/?bps_beneficioelegivelid=" + eligibleBenefitId;
}