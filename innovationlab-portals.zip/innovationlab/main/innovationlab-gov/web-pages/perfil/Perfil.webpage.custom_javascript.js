$(document).ready(function() {
    $("#ProfileFormView").closest("fieldset").hide();

    console.log("user name:");
    console.log('{{ user.firstname }}');
});