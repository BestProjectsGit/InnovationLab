$(document).ready(function() {
    $("#ProfileFormView").closest("fieldset").hide();

    var userFirstName = '{{ user.firstname }}';

    if (userFirstName.length == 0) {
        $("#documentos").closest("tr").hide();
    }
});