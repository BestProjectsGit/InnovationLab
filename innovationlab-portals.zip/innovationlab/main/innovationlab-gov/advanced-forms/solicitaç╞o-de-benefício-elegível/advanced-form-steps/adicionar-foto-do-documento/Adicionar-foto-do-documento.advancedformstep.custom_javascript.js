{% assign eligibleBenefitIdParam = request.params.bps_beneficioelegivelid %}
{% assign validatedParam = request.params.validado %}

$(document).ready(function() {
    if (localStorage.getItem("incidentid") == null) {
        $(".actions").hide();

        var checkIfHasDocumentFile = !($("#bps_fl_arquivo_delete_button").css('display') == 'none');

        if (checkIfHasDocumentFile) {
            $("#bps_fl_arquivo_delete_button").click();
        }

        $("#bps_st_numero").closest('tr').hide();

        $('#WebFormPanel').prev().before('<div class="alert alert-info"><strong>Adicione um arquivo para continuar</strong></div>');
    } else {
        debugger;
        $("#bps_fl_arquivo").closest('tr').hide();

        if (('{{ validatedParam }}' === 'true')) {
            $('#WebFormPanel').prev().before('<div class="alert alert-success"><strong>Seu documento foi validado com sucesso. Clique em avançar para ver mais informações.</strong></div>');
        } else {
            $("#bps_st_numero").closest('tr').hide();
            $('#WebFormPanel').prev().before('<div class="alert alert-info"><strong>Já foram realizadas 3 tentativas de validação e um protocolo foi criado para o seu caso. Entraremos em contato em breve.</br>Clique em avançar para ver mais informações.</strong></div>');
        }

        insertDocumentAttached();
        $(".actions").show();
    }

    $("#bps_fl_arquivo_input_file").change(function() {
        $('.alert').hide();
        var btnValidateDocument = document.getElementById("btnValidateDocument");

        if (btnValidateDocument == null && this.files.length > 0) {
            $("#bps_fl_arquivo").closest("tr").after('<tr><td colspan="1" rowspan="1" class="clearfix cell"><button id="btnValidateDocument" onclick="return validateDocument()" class="btn btn-primary button">Validar</button><img id="icon-aibuilder" style="display: none; width: 60px; margin-left: 40px" src="/aibuilder.gif"></td></tr>')
        }        
    });
});

function validateDocument() {   
    var documentSelected = $("#bps_tipodedocumento")[0].selectedIndex;
    $('.alert').hide();

    if (documentSelected != 0) {
        var totalRequests = parseInt(localStorage.getItem("solicitacaoDeBeneficioTentativas"));

        if (totalRequests == null || isNaN(totalRequests)) {
            totalRequests = 1;
            localStorage.setItem("solicitacaoDeBeneficioTentativas", totalRequests);
        } else if (totalRequests >= 3) {
            $('#WebFormPanel').prev().before('<div class="alert alert-info"><strong>Já foram realizadas 3 tentativas de validação e um protocolo foi criado para o seu caso. Entraremos em contato em breve.</strong></div>');
            
            return false;
        } else {
            totalRequests++;
            localStorage.setItem("solicitacaoDeBeneficioTentativas", totalRequests);
        }

        var file = $("#bps_fl_arquivo_input_file")[0].files[0];

        getBase64(file, function(e) {
            $('#btnValidateDocument')[0].disabled = true;

            var fileResult = e.target.result.split(',');
            var fileType = fileResult[0].replace('data:','');
            var extension = fileType.split('/')[1].split(';')[0];
            var base64 = fileResult[1];
            var documentType = $("#bps_tipodedocumento")[0].options[documentSelected].label;

            localStorage.setItem("base64",e.target.result);
            
            callAIBuilderDocumentValidation('{{ user.contactid }}','{{ eligibleBenefitIdParam }}', documentType, fileType, extension, base64, totalRequests);
        });

        return false;
    } else {
        $('#WebFormPanel').prev().before('<div class="alert alert-danger"><strong>Insira uma imagem e um tipo de documento para validar.</strong></div>');

        return false;
    }
}

function getBase64(file, onLoadCallback) {
   var reader = new FileReader();
   reader.onload = onLoadCallback;
   reader.readAsDataURL(file);

   reader.onerror = function (error) {
     console.log('Error: ' + error)
   };
}

function callAIBuilderDocumentValidation (userId, eligibleBenefitId, documentType, fileType, extension, base64, totalRequests) {
    $('#WebFormPanel').prev().before('<div class="alert alert-info"><strong>Aguarde enquanto seu documento está sendo validado.</strong></div>');
    $("#icon-aibuilder").show();

    flowURI = "https://prod-07.brazilsouth.logic.azure.com:443/workflows/ab3bb76f4b45427b9e920df45f93417a/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=ZhA0MkGEwU7hhIyJbGGCysyDdnF018b34a-WkOOYBGE"

    flowData = {
        idContato: userId,
        idBeneficioElegivel: eligibleBenefitId,
        idAssunto: "807f62fc-3b35-ed11-9db2-000d3a88f400",
        documento: documentType,
        extensao: extension,
        tipo: fileType,
        base64: base64,
        tentativa: totalRequests
    }

    $.ajax(
    {
        url: flowURI,
        data: JSON.stringify(flowData),
        processData: false,
        contentType: "application/json",
        dataType: "json",
        type: 'POST',
        complete: function(xhr, textStatus) 
        {
            $('.alert.alert-info').hide();
            $("#icon-aibuilder").hide();            

            var response = xhr.responseJSON;
            var blobDocumentImage = URL.createObjectURL($("#bps_fl_arquivo_input_file")[0].files[0]);
            sessionStorage.setItem("blobDocumentImage", JSON.stringify(blobDocumentImage));

            if (xhr.status == '200') {

                if ("idticket" in response) {
                    $("#bps_st_numero")[0].value = response.documento;
                    $("#bps_st_numero").closest('tr').show();

                    var validado = response.validado ? true : false;
                    var oldURL = window.location.href;

                    localStorage.setItem("incidentid", response.idticket);
                    window.location.assign(oldURL + "&incidentid=" + response.idticket + "&validado=" + validado);
                } else {
                    insertDocumentAttached();
                    $('#WebFormPanel').prev().before('<div class="alert alert-danger"><strong>' + response.response + '.</br></br>Número do documento lido: ' + response.documento + '</strong></div>');
                    $('#btnValidateDocument')[0].disabled = false;
                }
            } else {
                insertDocumentAttached();
                $('#WebFormPanel').prev().before('<div class="alert alert-danger"><strong>Houve um erro ao tentar validar seu documento. Tente novamente.</strong></div>');
                $('#btnValidateDocument')[0].disabled = false;
            }  
        }
    });    
}

function insertDocumentAttached() {
    var documentAttached = document.getElementById("documentAttached");

    if  (documentAttached == null) {
        var tableDocumentAttached = document.querySelectorAll('[data-name="documentoAnexado"]')[0];
        var columnToInsertImage = tableDocumentAttached.rows[0].children[0];
        var documentAttached = document.createElement('img');
        
        documentAttached.id = "documentAttached";
        documentAttached.src = localStorage.getItem("base64");
        documentAttached.style.maxWidth = "400px";
        
        columnToInsertImage.appendChild(documentAttached);
    } else {
        documentAttached.src = localStorage.getItem("base64");
    }
}