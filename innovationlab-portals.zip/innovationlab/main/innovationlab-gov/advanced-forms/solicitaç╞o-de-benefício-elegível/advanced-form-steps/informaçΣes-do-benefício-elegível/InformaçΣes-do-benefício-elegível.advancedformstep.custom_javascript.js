$(document).ready(function() {
    $("#bps_st_numero").closest('tr').hide();
    $("#bps_fl_arquivo_label").closest('tr').hide();
    localStorage.clear();
    sessionStorage.clear();

    var idBeneficioElegivel = $("#bps_beneficio")[0].value;
    localStorage.setItem("idBeneficioElegivel",idBeneficioElegivel);
});